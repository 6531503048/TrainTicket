public interface Prompt {
	public boolean PromptBoolean(String s);
	public int PromptInteger(String s, int i, int j);
	public String PromptString(String s, String t);
}
