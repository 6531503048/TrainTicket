public class MainProgram {
	public static void main(String[] args) {
		TrainTicket Program = new TrainTicket();
		Program.Start();
	}
}
